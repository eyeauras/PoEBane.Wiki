// Conditions belong to this rule: no automatic town/hideout policy is installed.
// Keywords: town, hideout, area, guard, condition, unknown
// Positive and negative predicates both return false while area facts are unknown.
OnTimer(1000)
  .If(() => NotInTown && NotInHideout && !IsInEscapeMenu)
  .Do(() => Log("Known area outside town and hideout; escape menu is closed."));

// Add other facts to your expression when needed, such as !IsChatOpen.
// IsInTown / IsInHideout remain nullable facts for distinguishing unknown data.
