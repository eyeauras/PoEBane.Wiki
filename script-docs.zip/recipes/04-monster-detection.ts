const DETECTION_RANGE: number = 45;

OnTimer(250)
  .If(() => {
    const life = Vitals?.HP.Percent;
    return life != null && life < 80 && MonsterCount(DETECTION_RANGE, MonsterRarity.AtLeastRare) > 0;
  })
  .Cooldown(1000)
  .Do(() => Osd.AddFloatingTextAtPlayer("Rare nearby"));
