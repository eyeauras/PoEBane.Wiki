const LOW_LIFE_PERCENT: number = 70;
const LIFE_FLASK_SLOT: number = 0;

OnTimer(100)
  .If(() => {
    const life = Vitals?.HP.Percent;
    return life != null && life < LOW_LIFE_PERCENT && Flasks.Flask1.CanBeUsed && !Flasks.Flask1.Active;
  })
  .Cooldown(500)
  .Do(() => World.Flasks.Use(LIFE_FLASK_SLOT));
