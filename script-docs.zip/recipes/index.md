---
title: Script recipes
description: Executable examples shipped with this build
published: true
tags: scripting, recipes
editor: markdown
---

## Recipes / Examples

1. Sequential waits and independent timers (`11-sequential-waits.ts`): Use Sleep directly in helpers and ordinary forEach; each OnTimer waits its period after completion.

```ts
// Ordinary helpers and forEach remain sequential; no async or await is needed.
function showItem(item: string) {
  Info(`Starting ${item}`);
  Sleep(1000);
  Info(`Finished ${item}`);
}

OnTimer(500).Do(() => {
  ["first", "second", "third"].forEach(showItem);
  Info("All finished; the next run starts after another 500 ms");
});

// This independent rule can finish while the first rule is sleeping.
OnTimer(100).Do(() => {
  Wait(300);
  Info("Independent rule completed");
});
```

2. Waiting for a condition (`12-wait-until.ts`): Sleep can appear in If. WaitUntil checks fresh state immediately, then polls until true or timeout.

```ts
OnTimer(100)
  .If(() => {
    Sleep(50);
    return !Input.IsKeyDown(Key.F1);
  })
  .Do(() => {
    const pressed = WaitUntil(
      () => Input.IsKeyDown(Key.F1),
      { timeoutMs: 5000, pollIntervalMs: 50 },
    );
    Info(pressed ? "F1 pressed" : "Timed out");
  });
```

3. Follow movement with sequential waits (`13-follow-with-sleep.ts`): Hold Space for a random duration, release, then wait again. Stop releases input through the host, without JS finally.

```ts
// Requires AutoFollow and a leader with a known distance. Random uses standard JavaScript.
OnTimer(100)
  .If(() => Ai.IsActive(Poe2Behavior.AutoFollow)
    && (Party.Leader?.DistanceToPlayer ?? 0) > 500)
  .Do(() => {
    Input.KeyDown(Key.Space);
    try {
      Sleep(1000 + Math.floor(Math.random() * 201));
    } finally {
      Input.KeyUp(Key.Space);
    }
    Sleep(50 + Math.floor(Math.random() * 51));
  });

// Stop destroys this sequence without JS finally; the host releases tracked held input.
// No overlapping activation or backlog accumulates during the two pauses.
```

4. Promise and setTimeout wait wrapper (`14-promise-timer-waits.ts`): Explicit async Do waits for its returned Promise; setTimeout alone schedules an independent callback.

```ts
// Explicit Promise wrappers remain supported. Prefer Sleep for simple sequential scripts.
function waitMs(milliseconds: number) {
  return new Promise<void>(resolve => setTimeout(resolve, milliseconds));
}

OnTimer(100)
  .If(() => Ai.IsActive(Poe2Behavior.AutoFollow)
    && (Party.Leader?.DistanceToPlayer ?? 0) > 500)
  .Do(async () => {
    Input.KeyDown(Key.Space);
    try {
      await waitMs(1000 + Math.floor(Math.random() * 201));
    } finally {
      Input.KeyUp(Key.Space);
    }
    await waitMs(50 + Math.floor(Math.random() * 51));
  });

// The returned Promise keeps this rule busy through both waits.
// Stop abandons pending continuation without JS finally; the host releases held input.
```

5. Flask consumption (`01-flask-consumption.ts`): Recurring HP flask logic belongs in `OnTimer`, not top-level one-shot code.

```ts
const LOW_LIFE_PERCENT: number = 70;
const LIFE_FLASK_SLOT: number = 0;

OnTimer(100)
  .If(() => {
    const life = Vitals?.HP.Percent;
    return life != null && life < LOW_LIFE_PERCENT && Flasks.Flask1.CanBeUsed && !Flasks.Flask1.Active;
  })
  .Cooldown(500)
  .Do(() => World.Flasks.Use(LIFE_FLASK_SLOT));
```

6. Feature toggles (`02-feature-toggle.ts`): Read the live feature state from `Ai` and flip it; do not maintain a mirror boolean.

```ts
OnHotkey(Key.F5).Do(() => {
  // Read the live state through Ai, flip it through the behavior's own named setter.
  const next: boolean = !Ai.IsEnabled(Poe2Behavior.AutoPickup);
  SetAutoPickup(next);
  Osd.AddFloatingTextAtPlayer(next ? "Auto pickup on" : "Auto pickup off");
});
```

7. Buff checks (`03-buff-check.ts`): The generated bare `Buffs` projection keeps read conditions compact inside a timer.

```ts
const BUFF_ID: string = "replace_with_buff_id";

OnTimer(250)
  .If(() => (Buffs.Current?.FindByDefinitionName(BUFF_ID).length ?? 0) > 0)
  .Cooldown(1000)
  .Do(() => {
    const buff = Buffs.Current?.FindByDefinitionName(BUFF_ID)[0];
    if (buff == null) {
      return;
    }
    Log(`${buff.DefinitionName}: ${buff.TimeRemainingSeconds?.toFixed(1) ?? "?"}s left`);
  });
```

8. Monster detection (`04-monster-detection.ts`): Generated WorldState projections combine into compact ReAgent-style conditions.

```ts
const DETECTION_RANGE: number = 45;

OnTimer(250)
  .If(() => {
    const life = Vitals?.HP.Percent;
    return life != null && life < 80 && MonsterCount(DETECTION_RANGE, MonsterRarity.AtLeastRare) > 0;
  })
  .Cooldown(1000)
  .Do(() => Osd.AddFloatingTextAtPlayer("Rare nearby"));
```

9. Holding buttons (`05-hold-key.ts`): Read the current key state from `Input`; do not maintain a second boolean.

```ts
const HELD_KEY: Key = Key.Space;

OnHotkey(Key.F9).Do(() => {
  if (Input.IsKeyDown(HELD_KEY)) {
    Input.KeyUp(HELD_KEY);
  } else {
    Input.KeyDown(HELD_KEY);
  }
});
```

10. Party-leader OSD arrow (`06-party-arrow.ts`): Use a per-frame timer because world OSD arrows must be refreshed while visible.

```ts
const ARROW_LENGTH: number = 20;

OnTimer(0).Do(() => {
  const player = Player;
  const leader = Party.Leader;
  const leaderEntity = leader ? World.PlayerByName(leader.Name) : null;
  if (!player || !leaderEntity || !leaderEntity.WorldPosition) {
    return;
  }

  const start = player.WorldPosition;
  const direction = player.directionTo(leaderEntity);
  if (!direction) {
    return;
  }

  const end = {
    X: start.X + direction.X * ARROW_LENGTH,
    Y: start.Y + direction.Y * ARROW_LENGTH,
    Z: start.Z + direction.Z * ARROW_LENGTH,
  };
  Osd.DrawArrowInWorld(start, end, { R: 120, G: 188, B: 255, A: 255 }, 3);
});
```

11. Flask and cooldown panel (`07-cooldown-panel.ts`): Use modern `World.Flasks`/`World.Skills` data and the generated bare `Osd` accessor.

```ts
const READY_COLOR: Color = { R: 80, G: 220, B: 120, A: 255 };
const WAIT_COLOR: Color = { R: 255, G: 160, B: 60, A: 255 };
const TEXT_COLOR: Color = { R: 255, G: 245, B: 220, A: 255 };

OnTimer(0).Do(() => {
  drawFlaskPanel();
  drawSkillCooldownSummary();
});

function drawFlaskPanel(): void {
  for (let slot = 0; slot < World.Flasks.Count; slot++) {
    const flask = World.Flasks.ByIndex(slot);
    if (!flask || !flask.HasItem) {
      continue;
    }

    const rect = World.Flasks.TryGetSlotClientRect(slot);
    if (!rect) {
      continue;
    }

    const color = flask.CanBeUsed ? READY_COLOR : WAIT_COLOR;
    Osd.DrawRectInClient(rect, color, 2);

    if (flask.Hotkey) {
      Osd.DrawTextInClient({ X: rect.X + 3, Y: rect.Y + 2 }, flask.Hotkey, TEXT_COLOR);
    }

    if (!flask.CanBeUsed) {
      Osd.DrawTextInClient(
        { X: rect.X + 8, Y: rect.Y + rect.Height - 16 },
        `${flask.Charges}/${flask.ChargesPerUse}`,
        WAIT_COLOR,
      );
    }
  }
}

function drawSkillCooldownSummary(): void {
  let row = 0;
  for (const skill of World.Skills.AllSkills) {
    if (!skill.Exists) {
      continue;
    }

    const cooldown = cooldownLeft(skill);
    if (skill.CanBeUsed && cooldown <= 0) {
      continue;
    }

    Osd.DrawTextInClient(
      { X: 18, Y: 180 + row * 14 },
      `${skill.Name}: ${formatSeconds(cooldown)}`,
      skill.CanBeUsed ? READY_COLOR : WAIT_COLOR,
    );
    row++;
    if (row >= 8) {
      break;
    }
  }
}

function cooldownLeft(skill: SkillInfo): number {
  let left = 0;
  for (const value of skill.Cooldowns || []) {
    left = Math.max(left, Number(value) || 0);
  }
  return left;
}

function formatSeconds(value: number): string {
  return value > 0 ? `${value.toFixed(1)}s` : "ready";
}
```

12. Owner skills and deployed summons (`08-owner-skills.ts`): Use one skill helper for player, weapon swap and entity owners; count live deployed entities and preserve duplicate buff instances.

```ts
// One helper works for Skills, WeaponSwapSkills and any entity's Skills.
// Keywords: summons, totems, deployed, owner, weapon swap, reagent
function liveSummons(skills: Poe2SkillsAccessor, name: string): number {
  return skills[name].DeployedEntities.filter(entity => entity.IsAlive).length;
}

OnTimer(1000).Do(() => {
  const name = "replace_with_skill_name";
  Log(`Active: ${liveSummons(Skills, name)}, swap: ${liveSummons(WeaponSwapSkills, name)}`);
  const player = Player;
  if (player !== null) {
    Log(`Player: ${liveSummons(player.Skills, name)}`);
    // Duplicate named instances stay separate; use AllBuffs/Current when every row matters.
    Log(`Bleeding instances: ${player.Buffs.AllBuffs.filter(buff => buff.Name === "bleeding").length}`);
  }
});
```

13. Explicit area conditions (`09-explicit-conditions.ts`): Compose town/hideout predicates in a rule expression; unknown area data does not pass negative guards.

```ts
// Conditions belong to this rule: no automatic town/hideout policy is installed.
// Keywords: town, hideout, area, guard, condition, unknown
// Positive and negative predicates both return false while area facts are unknown.
OnTimer(1000)
  .If(() => NotInTown && NotInHideout && !IsInEscapeMenu)
  .Do(() => Log("Known area outside town and hideout; escape menu is closed."));

// Add other facts to your expression when needed, such as !IsChatOpen.
// IsInTown / IsInHideout remain nullable facts for distinguishing unknown data.
```

14. Dread Banner while AutoFollow is enabled (`10-dread-banner-autofollow.ts`): Resolve Dread Banner's actual hotbar binding and press that slot only with AutoFollow enabled, known area outside town/hideout, and native/UI readiness. Unknown readiness blocks input; Glory is not a computed threshold.

```ts
// Uses Dread Banner's actual binding in the game's active mouse/WASD hotbar.
// Keywords: banner, glory, autofollow, readiness, combat, area
// "Combat area" here means a known area outside town/hideout, not actual combat.
function readyBannerSlot() {
  return World.SkillBar.Slots?.find(slot =>
    slot.Hotkey !== null && slot.Skill.InternalId === "dread_banner" &&
    slot.Skill.Exists && slot.Skill.CanBeUsed && slot.Skill.CanBeUsedInUi === true);
}

OnTimer(250)
  .If(() => {
    // IsEnabled reads the AutoFollow toggle; IsActive also includes the Automation gate.
    if (!World.Ai.IsEnabled(Poe2Behavior.AutoFollow) || !World.NotInPeacefulArea) {
      return false;
    }
    if (World.IsChatOpen || World.IsInEscapeMenu) return false;

    // Look up on each evaluation: retaining SkillInfo would retain older scalar facts.
    return readyBannerSlot() !== undefined;
  })
  // Input throttle, not the skill's cooldown or a Glory requirement calculation.
  .Cooldown(1000)
  .Do(() => readyBannerSlot()?.Press());

// Unreadable button data gives null readiness. The game may leave UI flags stale in the background.
// Input execution also follows the host's Automation gates; this rule never enables AutoFollow.
// Do not replace readiness with Glory >= RequiredGlory: modifiers can lower the requirement.
```

15. From a hotkey to a skill button (`11-skill-hotkeys.ts`): Read-only W/E/R, chord and mouse inspection: resolve the game's key binding to a hotbar slot and SkillInfo. Covers duplicate/unbound/unavailable states, optional guarded Press(), and a transient script_control_eval probe for AI/MCP.

```ts
// Key -> game binding -> hotbar slot (button) -> SkillInfo -> optional Press().
// Keywords: hotkey, keybind, keyboard, mouse, skill button, hotbar, slot, readiness, MCP
// This recipe only logs observations. It never presses a key or changes a game binding.
// World.SkillBar represents the player's active mouse/keyboard or WASD bar; controller is unavailable.
// A slot is not a UI Element: Press() sends its game hotkey at the current cursor, not a screen click.

function inspectSkillButtons(hotkey: Key | string) {
  // AllByHotkey is useful for diagnostics because it preserves duplicate assignments.
  // null = unavailable bar/config; [] = no match; one empty slot still has its Hotkey.
  const slots = World.SkillBar.AllByHotkey(hotkey);
  if (slots === null) return { hotkey, status: "unavailable", slots: null };
  return {
    hotkey,
    status: slots.length === 0 ? "unmatched" : slots.length > 1 ? "ambiguous" : "matched",
    slots: slots.map(slot => ({
      index: slot.Index,
      hotkey: slot.Hotkey,
      exists: slot.Skill.Exists,
      name: slot.Skill.Name,
      internalId: slot.Skill.InternalId,
      id: slot.Skill.Id,
      id2: slot.Skill.Id2,
      canBeUsed: slot.Skill.CanBeUsed,
      canBeUsedInUi: slot.Skill.CanBeUsedInUi,
    })),
  };
}

OnTimer(1000).Do(() => {
  // Key.W and "W" are equivalent; "Ctrl+W" is a different gesture.
  // Mouse aliases include "MouseLeft", "MouseMiddle", "MouseRight" and "Ctrl+MouseRight".
  Log(JSON.stringify([Key.W, Key.E, Key.R, "Ctrl+W", "MouseRight"].map(inspectSkillButtons)));
});

// Optional action helper: not called by this read-only recipe.
// Invoke from your own guarded/throttled rule when an actual skill press is wanted.
function pressReadySkillOn(hotkey: Key | string): boolean {
  if (World.IsChatOpen || World.IsInEscapeMenu) return false;
  // ByHotkey resolves one button. It throws on malformed input or multiple matching slots;
  // inspect AllByHotkey and fix the duplicate in game settings rather than guessing a slot.
  const slot = World.SkillBar.ByHotkey(hotkey);
  if (slot === null || slot.Hotkey === null || !slot.Skill.Exists) return false;
  if (!slot.Skill.CanBeUsed || slot.Skill.CanBeUsedInUi !== true) return false;
  return slot.Press(); // true = queued, not proof of a cast; readiness is the caller's policy.
}

// Re-resolve inside each evaluation; saved slot/SkillInfo scalar facts do not update themselves.
// Config normally refreshes every 100 ms. Before input dispatch the host refreshes it for the
// current memory frame and rejects changed session/skill/binding assignments. Input follows
// Automation/foreground gates and rejects already-held primary inputs or modifiers.
// Press also rejects a hotkey shared by multiple slots: selecting a slot cannot disambiguate input.
// Reads work in the background, but the GAME may leave its UI readiness flag stale there.
// CanBeUsedInUi=null means unreadable UI data; false is an unavailable, empty or unresolved skill.
// Hotkey=null means an unbound slot. Never substitute default QWERT keys or compact out empty slots.
// For a named skill, inspect World.SkillBar.Slots by Skill.InternalId or the exact Id/Id2 pair;
// one skill can occupy several slots. See 10-dread-banner-autofollow.ts for an action recipe.
// World.GameConfig.Input.GetHotkey("use_bound_skill5") reads an ACTION binding (not a skill).
// Check Input.IsAvailable to distinguish unavailable config from an unbound action; unknown
// actions/unsupported values throw when config is available. Do not derive slot indices from keys.

// AI / MCP investigation without replacing the user's persisted script:
// 1. Read this installed-build recipe/reference through the shared script-reference tools.
// 2. Call script_control_eval with plain JavaScript FUNCTION BODY source and an explicit return.
//    No TypeScript annotations/TSX, no OnTimer, no Press/Input calls are needed for inspection.
//    Example source:
//    const slots = World.SkillBar.AllByHotkey(Key.W);
//    return { available: World.GameConfig.Input.IsAvailable, slots: slots?.map(slot => ({
//      index: slot.Index, hotkey: slot.Hotkey, exists: slot.Skill.Exists,
//      name: slot.Skill.Name, ready: slot.Skill.CanBeUsedInUi
//    })) ?? null };
// 3. If the job is pending, use script_control_job_wait with its jobId; inspect errors explicitly.
// Return scalar projections like the above rather than opaque native handles.
// Eval is transient, but it can execute actions if you put them in its source; it is not a dry run.
```

16. Character class and ascendancy conditions (`12-character-class.ts`): Compare stable class/ascendancy IDs inside callbacks, display names separately from PlayerName, and distinguish unavailable data from no ascendancy selected.

```ts
// Keywords: character, class, ascendancy, specialization, build, condition, unknown
// Read inside callbacks so switching character or ascendancy updates the condition.
OnTimer(1000)
  .If(() => Player?.CharacterClass?.Id === CharacterClass.Mercenary)
  .Do(() => Log("Current character is a Mercenary."));

// Stable record ID: Ascendancy.Witchhunter === "Mercenary2".
OnTimer(1000)
  .If(() => World.Player?.CharacterClass?.Ascendancy?.Id === Ascendancy.Witchhunter)
  .Do(() => Log("Witchhunter condition passed."));

OnTimer(5000).Do(() => {
  const player = Player;
  const characterClass = player?.CharacterClass;
  if (characterClass == null) {
    Log("Character class unavailable.");
    return;
  }
  // PlayerName is the chosen character name; Name fields are display text.
  Log(`${player?.PlayerName}: ${characterClass.Name} — ${characterClass.Ascendancy?.Name ?? "No ascendancy selected"}`);
});

// A negative filter must require known data; undefined !== an ID would pass accidentally.
OnTimer(5000)
  .If(() => {
    const characterClass = Player?.CharacterClass;
    return characterClass != null && characterClass.Id !== CharacterClass.Mercenary;
  })
  .Do(() => Log("Known class other than Mercenary."));
```

