---
title: Script recipes
description: Executable examples shipped with this build
published: true
tags: scripting, recipes
editor: markdown
---

## Recipes / Examples

1. Life flask below 70% HP (`18-life-flask.ts`): Use Flask1 when health is low, charges permit it, and its recovery effect is inactive. The slot uses its default D1 key.

```ts
// Фласка здоровья при HP ниже 70%, если её эффект ещё не действует.
OnTimer(100)
  .If(() => Vitals.HP.Percent < 70 &&
    Flasks.Flask1.CanBeUsed && !Flasks.Flask1.Active)
  .Cooldown(500)
  .Do(() => Flasks.Flask1.Use());
```

2. Mana flask below 30% (`19-mana-flask.ts`): Use Flask2 when mana is low and its recovery effect is inactive. The slot uses its default D2 key.

```ts
// Фласка маны при запасе ниже 30%, если её эффект ещё не действует.
OnTimer(100)
  .If(() => Vitals.Mana.Percent < 30 &&
    Flasks.Flask2.CanBeUsed && !Flasks.Flask2.Active)
  .Cooldown(500)
  .Do(() => Flasks.Flask2.Use());
```

3. Maintain a timed buff (`20-maintain-buff.ts`): Replace my_guard_buff with a real definition name and bind its effect to E. Refresh when absent or below two seconds, outside town and hideout.

```ts
// Замените имя баффа; E должна включать соответствующий эффект.
const buffName = "my_guard_buff";

OnTimer(250)
  .If(() => !IsInPeacefulArea &&
    (!Buffs[buffName].Exists || Buffs[buffName].TimeLeft < 2))
  .Cooldown(1000)
  .Do(() => PressKey("E"));
```

4. Rare or unique enemy warning (`21-rare-warning.ts`): Show a two-second message for rare or unique enemies within 60 grid units; repeat at most every five seconds.

```ts
// Предупреждение о редком или уникальном противнике в радиусе 60.
OnTimer(250)
  .If(() => MonsterCount(60, MonsterRarity.AtLeastRare) > 0)
  .Cooldown(5000)
  .Do(() => Osd.WithTtl(2000).AddFloatingTextAtPlayer("Опасный противник рядом"));
```

5. Defensive skill when surrounded (`22-defensive-skill.ts`): Replace my_defensive_skill with a skill name or internal ID and bind it to R. Check low HP, five nearby enemies, and CanBeUsed; this predicate does not cover every game restriction.

```ts
// Замените имя навыка; R должна быть его клавишей в игре.
const defensiveSkill = "my_defensive_skill";

OnTimer(100)
  .If(() => !IsInPeacefulArea && Vitals.HP.Percent < 50 &&
    MonsterCount(30) >= 5 && Skills[defensiveSkill].CanBeUsed)
  .Cooldown(1500)
  .Do(() => PressKey("R"));
```

6. Two actions with a sequential pause (`23-key-sequence.ts`): F6 presses Q, waits 300 ms, then presses W outside town and hideout. Set the game bindings first; the delay does not confirm a successful cast.

```ts
// F6: два настроенных игровых действия с паузой 300 мс.
OnHotkey("F6")
  .If(() => !IsInPeacefulArea)
  .Do(() => {
    PressKey("Q");
    Sleep(300);
    PressKey("W");
  });
```

7. Wait for energy shield recovery (`24-wait-for-shield.ts`): For a character with energy shield: F7 waits for 90% ES, with a five-second timeout. WaitUntil returns a boolean; no async or Promise is needed.

```ts
// Для персонажа с ES: по F7 ждать восстановления до 90%, максимум 5 секунд.
OnHotkey("F7").Do(() => {
  if (WaitUntil(() => Vitals.ES.Percent >= 90, { timeoutMs: 5000 })) {
    Log("Энергетический щит восстановлен");
  } else {
    Log("Щит пока не восстановился");
  }
});
```

8. Death, revival, and timer cadence (`25-death-notification.ts`): Log death, wait for positive HP, then log revival. Only after Do finishes does the next 250 ms timer interval begin; other rules continue during the wait.

```ts
// Таймер ждёт завершения Do, затем отсчитывает следующие 250 мс.
OnTimer(250)
  .If(() => Vitals.HP.Current === 0)
  .Do(() => {
    Log("Персонаж погиб");
    WaitUntil(() => Vitals.HP.Current > 0);
    Log("Персонаж ожил");
  });
```

9. Report changes to the area name (`26-area-name-change.ts`): Log the first nonempty area name and later name changes. Another instance with the same name does not produce a new message.

```ts
// Сообщить текущее имя области при первом чтении и каждом изменении имени.
let previousArea = "";

OnTimer(500).Do(() => {
  const area = AreaName;
  if (area !== "" && area !== previousArea) {
    Log("Область: " + area);
    previousArea = area;
  }
});
```

10. Dread Banner near a rare enemy (`27-banner-by-game-binding.ts`): Find Dread Banner by its internal ID and press its actual game binding when native and UI readiness permit it. The cooldown limits attempts; Press queues input rather than confirming a cast.

```ts
// Dread Banner рядом с редким противником, с учётом реальной игровой привязки.
OnTimer(250)
  .If(() => !IsInPeacefulArea &&
    MonsterCount(60, MonsterRarity.AtLeastRare) > 0)
  .Cooldown(1000)
  .Do(() => {
    const slot = World.SkillBar.Slots?.find(slot =>
      slot.Skill.InternalId === "dread_banner" &&
      slot.Skill.CanBeUsed && slot.Skill.CanBeUsedInUi === true);

    if (slot) {
      slot.Press();
    }
  });
```

11. Cached HTTP JSON catalog (`15-http-catalog.ts`): Refresh a GET catalog infrequently, validate unknown JSON, and keep failures visible. Network work is asynchronous; JSON parsing stays on the script thread.

```ts
// PoeBane integration. Set your endpoint before enabling the rule.
const CATALOG_URL = "";
OnTimer(60_000).If(() => CATALOG_URL.length > 0).Do(async () => {
  try {
    await catalog.Refresh(CATALOG_URL);
    Log(`Catalog refreshed: ${catalog.Prices.size} prices`);
  } catch (error) {
    Warn(`Catalog unavailable: ${String(error)}`);
  }
});

// Application logic. Example payload: { "prices": { "Chaos Orb": 1.5 } }.
class PriceCatalog {
  Prices = new Map<string, number>();

  async Refresh(url: string): Promise<void> {
    // Clear stale values on failure rather than treating them as fresh prices.
    this.Prices.clear();
    const response = await fetch(url);
    if (response.status < 200 || response.status >= 300) {
      throw new Error(`HTTP ${response.status}`);
    }
    const payload: unknown = await response.json();
    if (typeof payload !== "object" || payload === null || !("prices" in payload)
        || typeof payload.prices !== "object" || payload.prices === null
        || Array.isArray(payload.prices)) {
      throw new Error("Expected a prices object");
    }
    const prices = new Map<string, number>();
    for (const [name, price] of Object.entries(payload.prices)) {
      if (typeof price !== "number" || !Number.isFinite(price) || price < 0) {
        throw new Error(`Invalid price for ${name}`);
      }
      prices.set(name, price);
    }
    this.Prices = prices;
  }
}
const catalog = new PriceCatalog();
```

12. HTN task phases and lifecycle (`16-task-lifecycle.ts`): An observation-only task demonstrates synchronous validators, awaited checkpoints, status, cancellation, and explicit rearming. No movement or purchases.

```ts
// PoeBane integration. Validators only read; task body actions are awaited.
const task = World.Tasks.Define("observe Ritual", HtnPriority.Normal,
  () => GameUi.RitualWindow?.IsVisible === true,
  async ctx => {
    await ctx.Checkpoint("wait for tribute", () => GameUi.RitualWindow?.IsVisible === true);
    await ctx.WaitUntil(() => (GameUi.RitualWindow?.Tribute ?? 0) > 0, 10_000);
    Log("Ritual has spendable tribute");
  });
OnTimer(1000).Do(() => Log(`${task.State}: ${task.PhaseName} ${task.Reason}`));

// A terminal task remains terminal. Call task.Rearm() to allow a new run.
// task.Cancel("user request") ends this run; task.Dispose() removes the definition.
// For controlled movement/input, use awaited ctx operations in the body.
// Global Sleep/WaitUntil use wall-clock scheduling; ctx.WaitUntil is an HTN operation.
```

13. Ritual rewards and OSD inspection (`17-ritual-observation.ts`): Read Tribute and current ordinary-mode offers, preserve unknown values, and draw reward costs without buying anything. Refresh native handles every callback.

```ts
// PoeBane integration: refresh this overlay each frame; keep native handles in this callback.
const TEXT_COLOR: Color = { R: 255, G: 235, B: 150, A: 255 };
OnTimer(0).Do(() => {
  const window = GameUi.RitualWindow;
  if (!window?.IsVisible) return;
  const tribute = window.Tribute;
  const rewards = window.Rewards;
  Osd.DrawTextInClient({ X: 20, Y: 180 },
    `Tribute: ${tribute ?? "unknown"}; rewards: ${rewards?.length ?? "unknown"}`, TEXT_COLOR);
  if (rewards === null) {
    Osd.DrawTextInClient({ X: 20, Y: 200 }, window.ReadError ?? "Rewards unavailable", TEXT_COLOR);
    return;
  }
  for (const reward of rewards) {
    const rect = reward.Element.ClientRect;
    if (!rect) continue;
    Osd.DrawRectInClient(rect, TEXT_COLOR, 1);
    Osd.DrawTextInClient({ X: rect.X + 2, Y: rect.Y + 2 },
      formatCost(reward.NormalCost), TEXT_COLOR);
  }
});

// Application formatting: null is unknown, never a free item.
function formatCost(cost: number | null): string {
  return cost === null ? "cost unknown" : `${cost} Tribute`;
}
// This API does not yet establish that this is the final Ritual on the map.
// Do not retain reward/item/element handles across await or a later frame.
```

14. Sequential waits and independent timers (`11-sequential-waits.ts`): Use Sleep directly in helpers and ordinary forEach; each OnTimer waits its period after completion.

```ts
// Ordinary helpers and forEach remain sequential; no async or await is needed.
function showItem(item: string) {
  Info(`Starting ${item}`);
  Sleep(1000);
  Info(`Finished ${item}`);
}

OnTimer(500).Do(() => {
  ["first", "second", "third"].forEach(showItem);
  Info("All finished; the next run starts after another 500 ms");
});

// This independent rule can finish while the first rule is sleeping.
OnTimer(100).Do(() => {
  Wait(300);
  Info("Independent rule completed");
});
```

15. Waiting for a condition (`12-wait-until.ts`): Sleep can appear in If. WaitUntil checks fresh state immediately, then polls until true or timeout.

```ts
OnTimer(100)
  .If(() => {
    Sleep(50);
    return !Input.IsKeyDown(Key.F1);
  })
  .Do(() => {
    const pressed = WaitUntil(
      () => Input.IsKeyDown(Key.F1),
      { timeoutMs: 5000, pollIntervalMs: 50 },
    );
    Info(pressed ? "F1 pressed" : "Timed out");
  });
```

16. Follow movement with sequential waits (`13-follow-with-sleep.ts`): Hold Space for a random duration, release, then wait again. Stop releases input through the host, without JS finally.

```ts
// Requires AutoFollow and a leader with a known distance. Random uses standard JavaScript.
OnTimer(100)
  .If(() => Ai.IsActive(Poe2Behavior.AutoFollow)
    && (Party.Leader?.DistanceToPlayer ?? 0) > 500)
  .Do(() => {
    Input.KeyDown(Key.Space);
    try {
      Sleep(1000 + Math.floor(Math.random() * 201));
    } finally {
      Input.KeyUp(Key.Space);
    }
    Sleep(50 + Math.floor(Math.random() * 51));
  });

// Stop destroys this sequence without JS finally; the host releases tracked held input.
// No overlapping activation or backlog accumulates during the two pauses.
```

17. Promise and setTimeout wait wrapper (`14-promise-timer-waits.ts`): Explicit async Do waits for its returned Promise; setTimeout alone schedules an independent callback.

```ts
// Explicit Promise wrappers remain supported. Prefer Sleep for simple sequential scripts.
function waitMs(milliseconds: number) {
  return new Promise<void>(resolve => setTimeout(resolve, milliseconds));
}

OnTimer(100)
  .If(() => Ai.IsActive(Poe2Behavior.AutoFollow)
    && (Party.Leader?.DistanceToPlayer ?? 0) > 500)
  .Do(async () => {
    Input.KeyDown(Key.Space);
    try {
      await waitMs(1000 + Math.floor(Math.random() * 201));
    } finally {
      Input.KeyUp(Key.Space);
    }
    await waitMs(50 + Math.floor(Math.random() * 51));
  });

// The returned Promise keeps this rule busy through both waits.
// Stop abandons pending continuation without JS finally; the host releases held input.
```

18. Flask consumption (`01-flask-consumption.ts`): Recurring HP flask logic belongs in `OnTimer`, not top-level one-shot code.

```ts
OnTimer(100)
  .If(() => Vitals.HP.Percent < 70 &&
    Flasks.Flask1.CanBeUsed && !Flasks.Flask1.Active)
  .Cooldown(500)
  .Do(() => World.Flasks.Use(0));

OnTimer(100)
  .If(() => Vitals.Mana.Percent < 70 &&
    Flasks.Flask2.CanBeUsed && !Flasks.Flask2.Active)
  .Cooldown(500)
  .Do(() => World.Flasks.Use(1));
```

19. Feature toggles (`02-feature-toggle.ts`): Read the live feature state from `Ai` and flip it; do not maintain a mirror boolean.

```ts
OnHotkey(Key.F5).Do(() => {
  // Read the live state through Ai, flip it through the behavior's own named setter.
  const next: boolean = !Ai.IsEnabled(Poe2Behavior.AutoPickup);
  SetAutoPickup(next);
  Osd.AddFloatingTextAtPlayer(next ? "Auto pickup on" : "Auto pickup off");
});
```

20. Buff checks (`03-buff-check.ts`): The generated bare `Buffs` projection keeps read conditions compact inside a timer.

```ts
const BUFF_ID: string = "replace_with_buff_id";

OnTimer(250)
  .If(() => (Buffs.Current?.FindByDefinitionName(BUFF_ID).length ?? 0) > 0)
  .Cooldown(1000)
  .Do(() => {
    const buff = Buffs.Current?.FindByDefinitionName(BUFF_ID)[0];
    if (buff == null) {
      return;
    }
    Log(`${buff.DefinitionName}: ${buff.TimeRemainingSeconds?.toFixed(1) ?? "?"}s left`);
  });
```

21. Monster detection (`04-monster-detection.ts`): Generated WorldState projections combine into compact ReAgent-style conditions.

```ts
const DETECTION_RANGE: number = 45;

OnTimer(250)
  .If(() => Vitals.HP.Percent < 80 && MonsterCount(DETECTION_RANGE, MonsterRarity.AtLeastRare) > 0)
  .Cooldown(1000)
  .Do(() => Osd.AddFloatingTextAtPlayer("Rare nearby"));
```

22. Holding buttons (`05-hold-key.ts`): Read the current key state from `Input`; do not maintain a second boolean.

```ts
const HELD_KEY: Key = Key.Space;

OnHotkey(Key.F9).Do(() => {
  if (Input.IsKeyDown(HELD_KEY)) {
    Input.KeyUp(HELD_KEY);
  } else {
    Input.KeyDown(HELD_KEY);
  }
});
```

23. Party-leader OSD arrow (`06-party-arrow.ts`): Use a per-frame timer because world OSD arrows must be refreshed while visible.

```ts
const ARROW_LENGTH: number = 20;

OnTimer(0).Do(() => {
  const player = Player;
  const leader = Party.Leader;
  const leaderEntity = leader ? World.PlayerByName(leader.Name) : null;
  if (!player || !leaderEntity || !leaderEntity.WorldPosition) {
    return;
  }

  const start = player.WorldPosition;
  const direction = player.directionTo(leaderEntity);
  if (!direction) {
    return;
  }

  const end = {
    X: start.X + direction.X * ARROW_LENGTH,
    Y: start.Y + direction.Y * ARROW_LENGTH,
    Z: start.Z + direction.Z * ARROW_LENGTH,
  };
  Osd.DrawArrowInWorld(start, end, { R: 120, G: 188, B: 255, A: 255 }, 3);
});
```

24. Flask and cooldown panel (`07-cooldown-panel.ts`): Use modern `World.Flasks`/`World.Skills` data and the generated bare `Osd` accessor.

```ts
const READY_COLOR: Color = { R: 80, G: 220, B: 120, A: 255 };
const WAIT_COLOR: Color = { R: 255, G: 160, B: 60, A: 255 };
const TEXT_COLOR: Color = { R: 255, G: 245, B: 220, A: 255 };

OnTimer(0).Do(() => {
  drawFlaskPanel();
  drawSkillCooldownSummary();
});

function drawFlaskPanel(): void {
  for (let slot = 0; slot < World.Flasks.Count; slot++) {
    const flask = World.Flasks.ByIndex(slot);
    if (!flask || !flask.HasItem) {
      continue;
    }

    const rect = World.Flasks.TryGetSlotClientRect(slot);
    if (!rect) {
      continue;
    }

    const color = flask.CanBeUsed ? READY_COLOR : WAIT_COLOR;
    Osd.DrawRectInClient(rect, color, 2);

    if (flask.Hotkey) {
      Osd.DrawTextInClient({ X: rect.X + 3, Y: rect.Y + 2 }, flask.Hotkey, TEXT_COLOR);
    }

    if (!flask.CanBeUsed) {
      Osd.DrawTextInClient(
        { X: rect.X + 8, Y: rect.Y + rect.Height - 16 },
        `${flask.Charges}/${flask.ChargesPerUse}`,
        WAIT_COLOR,
      );
    }
  }
}

function drawSkillCooldownSummary(): void {
  let row = 0;
  for (const skill of World.Skills.AllSkills) {
    if (!skill.Exists) {
      continue;
    }

    const cooldown = cooldownLeft(skill);
    if (skill.CanBeUsed && cooldown <= 0) {
      continue;
    }

    Osd.DrawTextInClient(
      { X: 18, Y: 180 + row * 14 },
      `${skill.Name}: ${formatSeconds(cooldown)}`,
      skill.CanBeUsed ? READY_COLOR : WAIT_COLOR,
    );
    row++;
    if (row >= 8) {
      break;
    }
  }
}

function cooldownLeft(skill: SkillInfo): number {
  let left = 0;
  for (const value of skill.Cooldowns || []) {
    left = Math.max(left, Number(value) || 0);
  }
  return left;
}

function formatSeconds(value: number): string {
  return value > 0 ? `${value.toFixed(1)}s` : "ready";
}
```

25. Owner skills and deployed summons (`08-owner-skills.ts`): Use one skill helper for player, weapon swap and entity owners; count live deployed entities and preserve duplicate buff instances.

```ts
// One helper works for Skills, WeaponSwapSkills and any entity's Skills.
// Keywords: summons, totems, deployed, owner, weapon swap, reagent
function liveSummons(skills: Poe2SkillsAccessor, name: string): number {
  return skills[name].DeployedEntities.filter(entity => entity.IsAlive).length;
}

OnTimer(1000).Do(() => {
  const name = "replace_with_skill_name";
  Log(`Active: ${liveSummons(Skills, name)}, swap: ${liveSummons(WeaponSwapSkills, name)}`);
  const player = Player;
  if (player !== null) {
    Log(`Player: ${liveSummons(player.Skills, name)}`);
    // Duplicate named instances stay separate; use AllBuffs/Current when every row matters.
    Log(`Bleeding instances: ${player.Buffs.AllBuffs.filter(buff => buff.Name === "bleeding").length}`);
  }
});
```

26. Explicit area conditions (`09-explicit-conditions.ts`): Compose town/hideout predicates in a rule expression; unknown area data does not pass negative guards.

```ts
// Conditions belong to this rule: no automatic town/hideout policy is installed.
// Unknown area flags default to false, so their negation passes too.
OnTimer(1000)
  .If(() => !IsInTown && !IsInHideout && !IsInEscapeMenu)
  .Do(() => Log("Outside town and hideout; escape menu is closed."));

// Area.Current and the explicit NotInTown/NotInHideout guards are available when knowledge matters.
```

27. Dread Banner while AutoFollow is enabled (`10-dread-banner-autofollow.ts`): Resolve Dread Banner's actual hotbar binding and press that slot only with AutoFollow enabled, known area outside town/hideout, and native/UI readiness. Unknown readiness blocks input; Glory is not a computed threshold.

```ts
// Uses Dread Banner's actual binding in the game's active mouse/WASD hotbar.
// Keywords: banner, glory, autofollow, readiness, combat, area
// "Combat area" here means a known area outside town/hideout, not actual combat.
function readyBannerSlot() {
  return World.SkillBar.Slots?.find(slot =>
    slot.Hotkey !== null && slot.Skill.InternalId === "dread_banner" &&
    slot.Skill.Exists && slot.Skill.CanBeUsed && slot.Skill.CanBeUsedInUi === true);
}

OnTimer(250)
  .If(() => {
    // IsEnabled reads the AutoFollow toggle; IsActive also includes the Automation gate.
    if (!World.Ai.IsEnabled(Poe2Behavior.AutoFollow) || !World.NotInPeacefulArea) {
      return false;
    }
    if (World.IsChatOpen || World.IsInEscapeMenu) return false;

    // Look up on each evaluation: retaining SkillInfo would retain older scalar facts.
    return readyBannerSlot() !== undefined;
  })
  // Input throttle, not the skill's cooldown or a Glory requirement calculation.
  .Cooldown(1000)
  .Do(() => readyBannerSlot()?.Press());

// Unreadable button data gives null readiness. The game may leave UI flags stale in the background.
// Input execution also follows the host's Automation gates; this rule never enables AutoFollow.
// Do not replace readiness with Glory >= RequiredGlory: modifiers can lower the requirement.
```

28. From a hotkey to a skill button (`11-skill-hotkeys.ts`): Read-only W/E/R, chord and mouse inspection: resolve the game's key binding to a hotbar slot and SkillInfo. Covers duplicate/unbound/unavailable states, optional guarded Press(), and a transient script_control_eval probe for AI/MCP.

```ts
// Key -> game binding -> hotbar slot (button) -> SkillInfo -> optional Press().
// Keywords: hotkey, keybind, keyboard, mouse, skill button, hotbar, slot, readiness, MCP
// This recipe only logs observations. It never presses a key or changes a game binding.
// World.SkillBar represents the player's active mouse/keyboard or WASD bar; controller is unavailable.
// A slot is not a UI Element: Press() sends its game hotkey at the current cursor, not a screen click.

function inspectSkillButtons(hotkey: Key | string) {
  // AllByHotkey is useful for diagnostics because it preserves duplicate assignments.
  // null = unavailable bar/config; [] = no match; one empty slot still has its Hotkey.
  const slots = World.SkillBar.AllByHotkey(hotkey);
  if (slots === null) return { hotkey, status: "unavailable", slots: null };
  return {
    hotkey,
    status: slots.length === 0 ? "unmatched" : slots.length > 1 ? "ambiguous" : "matched",
    slots: slots.map(slot => ({
      index: slot.Index,
      hotkey: slot.Hotkey,
      exists: slot.Skill.Exists,
      name: slot.Skill.Name,
      internalId: slot.Skill.InternalId,
      id: slot.Skill.Id,
      id2: slot.Skill.Id2,
      canBeUsed: slot.Skill.CanBeUsed,
      canBeUsedInUi: slot.Skill.CanBeUsedInUi,
    })),
  };
}

OnTimer(1000).Do(() => {
  // Key.W and "W" are equivalent; "Ctrl+W" is a different gesture.
  // Mouse aliases include "MouseLeft", "MouseMiddle", "MouseRight" and "Ctrl+MouseRight".
  Log(JSON.stringify([Key.W, Key.E, Key.R, "Ctrl+W", "MouseRight"].map(inspectSkillButtons)));
});

// Optional action helper: not called by this read-only recipe.
// Invoke from your own guarded/throttled rule when an actual skill press is wanted.
function pressReadySkillOn(hotkey: Key | string): boolean {
  if (World.IsChatOpen || World.IsInEscapeMenu) return false;
  // ByHotkey resolves one button. It throws on malformed input or multiple matching slots;
  // inspect AllByHotkey and fix the duplicate in game settings rather than guessing a slot.
  const slot = World.SkillBar.ByHotkey(hotkey);
  if (slot === null || slot.Hotkey === null || !slot.Skill.Exists) return false;
  if (!slot.Skill.CanBeUsed || slot.Skill.CanBeUsedInUi !== true) return false;
  return slot.Press(); // true = queued, not proof of a cast; readiness is the caller's policy.
}

// Re-resolve inside each evaluation; saved slot/SkillInfo scalar facts do not update themselves.
// Config normally refreshes every 100 ms. Before input dispatch the host refreshes it for the
// current memory frame and rejects changed session/skill/binding assignments. Input follows
// Automation/foreground gates and rejects already-held primary inputs or modifiers.
// Press also rejects a hotkey shared by multiple slots: selecting a slot cannot disambiguate input.
// Reads work in the background, but the GAME may leave its UI readiness flag stale there.
// CanBeUsedInUi=null means unreadable UI data; false is an unavailable, empty or unresolved skill.
// Hotkey=null means an unbound slot. Never substitute default QWERT keys or compact out empty slots.
// For a named skill, inspect World.SkillBar.Slots by Skill.InternalId or the exact Id/Id2 pair;
// one skill can occupy several slots. See 10-dread-banner-autofollow.ts for an action recipe.
// World.GameConfig.Input.GetHotkey("use_bound_skill5") reads an ACTION binding (not a skill).
// Check Input.IsAvailable to distinguish unavailable config from an unbound action; unknown
// actions/unsupported values throw when config is available. Do not derive slot indices from keys.

// AI / MCP investigation without replacing the user's persisted script:
// 1. Read this installed-build recipe/reference through the shared script-reference tools.
// 2. Call script_control_eval with plain JavaScript FUNCTION BODY source and an explicit return.
//    No TypeScript annotations/TSX, no OnTimer, no Press/Input calls are needed for inspection.
//    Example source:
//    const slots = World.SkillBar.AllByHotkey(Key.W);
//    return { available: World.GameConfig.Input.IsAvailable, slots: slots?.map(slot => ({
//      index: slot.Index, hotkey: slot.Hotkey, exists: slot.Skill.Exists,
//      name: slot.Skill.Name, ready: slot.Skill.CanBeUsedInUi
//    })) ?? null };
// 3. If the job is pending, use script_control_job_wait with its jobId; inspect errors explicitly.
// Return scalar projections like the above rather than opaque native handles.
// Eval is transient, but it can execute actions if you put them in its source; it is not a dry run.
```

29. Character class and ascendancy conditions (`12-character-class.ts`): Compare stable class/ascendancy IDs inside callbacks, display names separately from PlayerName, and distinguish unavailable data from no ascendancy selected.

```ts
// Keywords: character, class, ascendancy, specialization, build, condition, unknown
// Read inside callbacks so switching character or ascendancy updates the condition.
OnTimer(1000)
  .If(() => Player?.CharacterClass?.Id === CharacterClass.Mercenary)
  .Do(() => Log("Current character is a Mercenary."));

// Stable record ID: Ascendancy.Witchhunter === "Mercenary2".
OnTimer(1000)
  .If(() => World.Player?.CharacterClass?.Ascendancy?.Id === Ascendancy.Witchhunter)
  .Do(() => Log("Witchhunter condition passed."));

OnTimer(5000).Do(() => {
  const player = Player;
  const characterClass = player?.CharacterClass;
  if (characterClass == null) {
    Log("Character class unavailable.");
    return;
  }
  // PlayerName is the chosen character name; Name fields are display text.
  Log(`${player?.PlayerName}: ${characterClass.Name} — ${characterClass.Ascendancy?.Name ?? "No ascendancy selected"}`);
});

// A negative filter must require known data; undefined !== an ID would pass accidentally.
OnTimer(5000)
  .If(() => {
    const characterClass = Player?.CharacterClass;
    return characterClass != null && characterClass.Id !== CharacterClass.Mercenary;
  })
  .Do(() => Log("Known class other than Mercenary."));
```

