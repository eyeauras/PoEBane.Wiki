# PoeBane script OSD: draw every frame

Client-space script OSD is rendered through ImGui, an immediate-mode renderer. A persistent element
needs drawing commands on every render frame; it is not retained automatically after initialization,
a value change, or a slow timer. In the current PoeBane script API, use `OnTimer(0).Do(...)` to enqueue
its drawing commands every script tick; the native overlay renders those commands. There is no script
`OnRender` callback to invent. The default OSD command batch is replaced each tick.

Separate data preparation from drawing. Expensive reads/calculations may run less often and cache their
result, but the draw rule must submit that result every tick while the element should be visible. Do not
put a positive timer interval, cooldown, or change-only condition around a continuously visible drawing.

```typescript
const TEXT_COLOR: Color = { R: 255, G: 245, B: 220, A: 255 };
let hpText: string = "HP: unavailable";

// Refresh data at 4 Hz. Retain only the display value between ticks.
OnTimer(250).Do(() => {
  const percent = Vitals?.HP.Percent;
  hpText = percent != null ? `HP: ${percent.toFixed(0)}%` : "HP: unavailable";
});

// Draw continuously, including ticks with no new data.
OnTimer(0).Do(() => {
  Osd.DrawTextInClient({ X: 18, Y: 180 }, hpText, TEXT_COLOR);
});
```

For an intentionally one-shot notification, `Osd.WithTtl(ms)` explicitly retains its commands for the
requested lifetime (for example, a hotkey toast). This explicit lifetime is different from default
per-tick OSD and is not needed for a continuously redrawn panel. `UI` React windows are a separate API;
do not confuse their retained component state with ImGui drawing commands.
