---
title: PoeBane scripting
description: Local reference for the scripting API embedded in this application
published: true
tags: scripting
editor: markdown
---

# PoeBane scripting

This reference is generated and bundled with the running application. Use it when writing or editing
scripts; do not infer API names from another product or an older conversation.

- [API index](api/index): globals, types, members and extension declarations.
- [Recipes](recipes/index): executable examples tested with this build. The adjacent `.ts` files contain
  the exact snippets.
- [OSD drawing](osd): draw persistent ImGui OSD every tick while refreshing cached data separately.
- [Execution, waits and timers](execution-and-waits): sequential Sleep without await, independent
  rules, WaitUntil, setTimeout, explicit Promises and Stop.
- `recipes/11-skill-hotkeys.ts`: key/chord/mouse button → hotbar slot → skill readiness → optional input;
  includes a read-only AI/MCP investigation snippet and duplicate/unbound/unavailable cases.
- `poebane.d.ts`: authoritative TypeScript signatures and JSDoc used by Studio Monaco.
- `poebane.script-api.json`: generated API provenance and feature requirements.

Search local files with `rg` or the available file-search tool, then read the relevant declaration before
using an unfamiliar member. Large tables, particularly GameStat, are easier to search than read in full.

Studio AI and the per-game MCP endpoint also expose the same `script_reference_search(query)` and
`script_reference_read(path, startLine?, lineCount?)` tools. Search returns exact paths and one-based line
numbers; read returns `nextLine` when more remains. These read the embedded bundle, so they work without
filesystem access. Use exact file extensions with these tools (`api/index.md`, `recipes/index.md`),
even though Wiki.js links omit `.md`. Both results include `bundleHash` to identify the installed reference.

For live investigation, use `script_control_eval` with a JavaScript function body and an explicit
`return`, then `script_control_job_wait` if the job is pending. A diagnostic can resolve
`World.SkillBar.AllByHotkey(Key.W)` and return scalar fields such as `Index`, `Hotkey`, `Skill.Name` and
`Skill.CanBeUsedInUi`. This does not replace the saved script. Eval is executable code, not a dry run:
omit `Press`, `Input` and lifecycle commands when only inspecting state. The hotkey recipe contains
copyable source. For persisted changes, read the current script first and pass its hash to the write tool.

## Authoring

Studio scripts use TypeScript/TSX. Keep recurring behavior inside the rule/event DSL (`OnTimer`, `Rule`,
and related builders); top-level code runs at script initialization. Follow the actual signatures and
nullable types in the declarations. `UI` creates React script windows; `GameUi` / `World.GameUi` reads
the game's UI tree. `@requiresFeature` means the corresponding live feature must be enabled.

Use the application's script-control tools to inspect and edit the real script. Do not execute a script
just to check its types: execution may send input or alter automation. Check compiler diagnostics and
report the checks actually performed; this reference does not provide a standalone semantic checker.

The documentation directory is a generated, read-only reference. Write user scripts in their own
workspace. Changes to this cache are replaced by the application when the bundled reference changes.
