---
title: PoeBane scripting
description: Local reference for the scripting API embedded in this application
published: true
tags: scripting
editor: markdown
---

# PoeBane scripting

This reference is generated and bundled with the running application. Use it when writing or editing
scripts; do not infer API names from another product or an older conversation.

- [API index](api/index): globals, types, members and extension declarations.
- [Recipes](recipes/index): executable examples tested with this build. The adjacent `.ts` files contain
  the exact snippets.
- [OSD drawing](osd): draw persistent ImGui OSD every tick while refreshing cached data separately.
- [Execution, waits and timers](execution-and-waits): sequential Sleep without await, independent
  rules, WaitUntil, setTimeout, explicit Promises and Stop.
- `recipes/11-skill-hotkeys.ts`: key/chord/mouse button → hotbar slot → skill readiness → optional input;
  includes a read-only AI/MCP investigation snippet and duplicate/unbound/unavailable cases.
- `poebane.d.ts`: authoritative TypeScript signatures and JSDoc used by Studio Monaco.
- `poebane.script-api.json`: generated API provenance and feature requirements.

Use the documentation route supplied by this conversation. Start with recipe filenames or the recipe
index, read the matching recipe, then look up only unfamiliar declarations. For flask automation,
`recipes/01-flask-consumption.ts` already covers the timer, HP threshold, readiness, cooldown and use.
Stop discovery once the example and signatures cover the task. Large tables such as GameStat should
only be searched for a task that actually needs their entries.

When local file access is available, use the supplied absolute reference directory with your file
read/search tools. Scope searches to recipes first and then the relevant API files. Do not assume a
particular shell or command is installed.

Clients without local access use the published `script_reference_search(query, pathPrefix?)` and
`script_reference_read(path, startLine?, lineCount?)` tools. Search prioritizes matching paths and
limits matches from each file; narrow with `pathPrefix` such as `recipes/` or `api/types/` when results
are truncated. Results carry exact paths and one-based line numbers. Read defaults to startLine 1 and
lineCount 100, accepts at most 200 lines and 32768 UTF-8 content bytes, and returns `nextLine` for
continuation. Use exact extensions (`api/index.md`, `recipes/index.md`), even though Wiki.js links omit
`.md`. Tool responses include the installed `bundleHash`. The tools and local directory use the same
embedded documentation; they are delivery routes, not separate reference sources.

For live investigation, use `script_control_eval` with a JavaScript function body and an explicit
`return`, then `script_control_job_wait` if the job is pending. A diagnostic can resolve
`World.SkillBar.AllByHotkey(Key.W)` and return scalar fields such as `Index`, `Hotkey`, `Skill.Name` and
`Skill.CanBeUsedInUi`. This does not replace the saved script. Eval is executable code, not a dry run:
omit `Press`, `Input` and lifecycle commands when only inspecting state. The hotkey recipe contains
copyable source. For persisted changes, read and edit the current script through ordinary filesystem tools at its absolute path.

## Authoring

Studio scripts use TypeScript/TSX. Keep recurring behavior inside the rule/event DSL (`OnTimer`, `Rule`,
and related builders); top-level code runs at script initialization. Follow the actual signatures and
nullable types in the declarations. `UI` creates React script windows; `GameUi` / `World.GameUi` reads
the game's UI tree. `@requiresFeature` means the corresponding live feature must be enabled.

Use filesystem tools to edit user scripts; script-control tools handle runtime operations, not source
editing. Do not execute a script just to check its types: execution may send input or alter automation.
Check available compiler diagnostics and report the checks actually performed; this reference does not
provide a standalone semantic checker.

The documentation directory is a generated, read-only reference. Write user scripts in their own
workspace. Changes to this cache are replaced by the application when the bundled reference changes.
